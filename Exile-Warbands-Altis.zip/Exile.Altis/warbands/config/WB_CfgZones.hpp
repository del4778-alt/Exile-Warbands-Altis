WB_zones = [
  ["Kavala","Kavala",3,"KAV",20],
  ["KavalaOutskirts","Kavala Outskirts",1,"KAV",10],
  ["Pyrgos","Pyrgos",3,"PYR",20],
  ["PyrgosIndustrial","Pyrgos Industrial",2,"PYR",10],
  ["Athira","Athira",3,"ATH",20],
  ["AthiraFarm","Athira Farmlands",1,"ATH",10],
  ["Sofia","Sofia",3,"CIV",20],
  ["SofiaMine","Sofia Mine",2,"CIV",10]
];
