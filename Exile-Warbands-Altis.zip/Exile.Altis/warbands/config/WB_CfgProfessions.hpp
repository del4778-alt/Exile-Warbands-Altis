WB_professions = [
  ["MERCENARY",["Leadership",1.10],["Tactics",1.05]],
  ["TRADER",   ["Trading",1.20],["Roguery",0.90]],
  ["BANDIT",   ["Roguery",1.25],["Trading",0.85]],
  ["OFFICER",  ["Leadership",1.20],["Tactics",1.10]],
  ["SMITH",    ["Smithing",1.25],["Riding",1.00]]
];
