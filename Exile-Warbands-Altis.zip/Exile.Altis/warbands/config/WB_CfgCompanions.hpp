WB_companions = [
  ["Roderick","KAV",["Leadership",0.05],["Tactics",0.05]],
  ["Siora","PYR",["Trading",0.10],["Roguery",0.05]],
  ["Dagan","ATH",["Smithing",0.15]],
  ["Mira","CIV",["Riding",0.10],["Leadership",0.03]]
];
WB_companionHireCost = 8000;
